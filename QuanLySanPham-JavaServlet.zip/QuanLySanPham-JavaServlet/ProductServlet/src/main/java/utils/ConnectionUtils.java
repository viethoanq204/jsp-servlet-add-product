package utils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtils {

	public ConnectionUtils() {
		// TODO Auto-generated constructor stub
	}
	public static Connection getConnection() 
            throws ClassNotFoundException, SQLException {
		 String hostName = "localhost";
		    String dbName = "k7g";
		    String userName = "root";
		    String password = "";
		    Class.forName("com.mysql.jdbc.Driver");		    
		    // Cấu trúc URL Connection dành cho MySQL		   
		    String connectionURL = "jdbc:mysql://" + hostName + ":3306/" + dbName+"?autoReconnect=true&useSSL=false";
		    System.out.println("URL: "+connectionURL);
		    Connection conn = DriverManager.getConnection(connectionURL, userName,
		            password);
		    System.out.println("ket noi ok");
		    return conn;
    
  }
   
  public static void closeQuietly(Connection conn) {
      try {
          conn.close();
      } catch (Exception e) {
      }
  }

  public static void rollbackQuietly(Connection conn) {
      try {
          conn.rollback();
      } catch (Exception e) {
      }
  }
  public static void main(String[] args) {
	  try {
	Connection con=ConnectionUtils.getConnection();
	  }catch(SQLException e) {
		  e.printStackTrace();
	  }catch(ClassNotFoundException e1) {
		  
	  }
	  
}

}
package servlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Product;
import utils.ConnectionUtils;
import utils.DBUtils;

/**
 * Servlet implementation class EditProductServlet
 */
@WebServlet("/editProduct")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con1=(Connection)request.getAttribute("con");
		String errorString1=(String)request.getAttribute("errorString");
		String code = (String) request.getParameter("code");
		Product product = null;

		try {
			product = DBUtils.findProduct(con1, code);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString1 = e.getMessage();
		}
		// neu san pham khong ton tai hoac co loi forward sang productList
		if (errorString1 != null && product == null) {
			response.sendRedirect(request.getServletPath() + "/productList");
			return;
		}
		// lu thong tin vao request attribute truoc khi sang views
		request.setAttribute("erroString", errorString1);
		request.setAttribute("product", product);
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/editProductView.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con1=(Connection)request.getAttribute("con");
		String errorString1=(String)request.getAttribute("errorString");
			String code = (String) request.getParameter("code");				
			String name=(String)request.getParameter("name");
			String priceStr=(String)request.getParameter("price");
			
			float price=0;
			try { price=Float.parseFloat(priceStr);
			
		}catch(NumberFormatException e) {
			e.printStackTrace();
			errorString1=e.getMessage();
			
		}
			Product product=new Product(code,name,price);
		
		
		try {
			DBUtils.updateProduct(con1, product);
			ConnectionUtils.closeQuietly(con1);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString1 = e.getMessage();
		}
		// luu thong tin vao attribute truoc khi forward Views
		request.setAttribute("errorString", errorString1);
		request.setAttribute("product", product);
		// neu co loi forward lai trang edit
		if (errorString1 != null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/WEB-INF/views/editproductView.jsp");
			dispatcher.forward(request, response);
		} else {
			// neu khong co loi Redirect sang trang danh sach san pham
			response.sendRedirect(request.getContextPath() + "/productList");
		}

	}
}
package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Product;
import utils.ConnectionUtils;
import utils.DBUtils;




/**
 * Servlet implementation class CreateProductServlet
 */
@WebServlet("/createProduct")
public class CreateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispastcher=request.getServletContext().getRequestDispatcher("/WEB-INF/views/createProductView.jsp");
		dispastcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con1=(Connection)request.getAttribute("con");
		String errorString1=(String)request.getAttribute("errorString");
		String code=(String)request.getParameter("code");
		String name=(String)request.getParameter("name");
		String priceStr=(String)request.getParameter("price");		
		float price=0;
		try {
			price=Float.parseFloat(priceStr);
		}catch(NumberFormatException e) {
			e.printStackTrace();
			errorString1=e.getMessage();
		}
		Product product=new Product(code,name,price);
		String regex="\\w";
		if(code==null||code.matches(regex)) {
			errorString1="Product Code invalid";
		}
		if(errorString1==null) {
			try {
				DBUtils.insertProduct(con1, product);
				ConnectionUtils.closeQuietly(con1);
				
			}catch(SQLException e) {
				e.printStackTrace();
				errorString1=e.getMessage();
			}
		}
		//luu thong tin vao requets truoc khi forward sang view
		request.setAttribute("errorString",errorString1);
		request.setAttribute("product",product);
		//neu co loi forward sang trang "createProductView.jsp neu khong chuyen huong sang productList
		if(errorString1!=null) {
			RequestDispatcher dispatcher=request.getServletContext().getRequestDispatcher("/WEB-INF/views/createProductView.jsp");
			dispatcher.forward(request, response);
		}else {
			response.sendRedirect(request.getContextPath()+"/productList");
		}
		 
	}

}

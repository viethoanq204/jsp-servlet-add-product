package filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

import utils.ConnectionUtils;

@WebFilter(urlPatterns = {"/productList", "/createProduct", "/deleteProduct", "/editProduct"})
public class DatabaseFilter extends HttpFilter implements Filter {
    
    public DatabaseFilter() {
        super();
    }

    public void destroy() {
    }
    

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		Connection con=null;
		String errorString=null;
		try {
		 con=ConnectionUtils.getConnection();
		}
		catch(SQLException e) {
			errorString=e.getMessage();
		}
		catch(ClassNotFoundException e1) {
			errorString=e1.getMessage();
		}
		request.setAttribute("con", con);
		request.setAttribute("errorString", errorString);
		System.out.println("qua fillter");
		chain.doFilter(request, response);
	}

//    package filter;
//
//    import java.io.IOException;
//    import java.sql.Connection;
//    import java.sql.SQLException;
//
//    import javax.servlet.Filter;
//    import javax.servlet.FilterChain;
//    import javax.servlet.FilterConfig;
//    import javax.servlet.ServletException;
//    import javax.servlet.ServletRequest;
//    import javax.servlet.ServletResponse;
//    import javax.servlet.annotation.WebFilter;
//    import javax.servlet.http.HttpFilter;
//
//    import utils.ConnectionUtils;
//
//    @WebFilter(urlPatterns = {"/productList", "/createProduct", "/deleteProduct", "/editProduct"})
//    public class DatabaseFilter extends HttpFilter implements Filter {
//
//        public DatabaseFilter() {
//            super();
//        }
//
//        public void destroy() {
//            // Không cần xử lý thêm ở đây
//        }
//
//        public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//                throws IOException, ServletException {
//            Connection con = null;
//            try {
//                con = ConnectionUtils.getConnection();
//
//                // Nếu kết nối bị null thì báo lỗi và dừng xử lý
//                if (con == null) {
//                    throw new ServletException("Không thể kết nối đến cơ sở dữ liệu (Connection = null).");
//                }
//
//                // Gắn connection vào request để các servlet có thể sử dụng
//                request.setAttribute("con", con);
//                System.out.println("✅ Đã kết nối DB qua filter.");
//
//                // Tiếp tục xử lý request
//                chain.doFilter(request, response);
//
//            } catch (SQLException | ClassNotFoundException e) {
//                e.printStackTrace();
//                throw new ServletException("Lỗi khi kết nối cơ sở dữ liệu: " + e.getMessage());
//            } finally {
//                // Đóng kết nối sau khi xử lý xong
//                if (con != null) {
//                    try {
//                        con.close();
//                        System.out.println("✅ Đã đóng kết nối DB sau khi xử lý.");
//                    } catch (SQLException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }
//
//      


    public void init(FilterConfig fConfig) throws ServletException {
    }
}